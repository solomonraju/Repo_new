// This header is included with every file for the Mac build
#define _MAC
#define XP_MAC

#if defined(__MACH__) && defined(__GNUC__) && __GNUC__
	//	GCC compiling for Mach-O target. Assume XCode
	#define __XCODE__ 1
	#if !defined(__XCODE_MSL__) || (!__XCODE_MSL__)
		#define __XCODE_GLIBC__ 1
	#endif
#endif

#ifdef __MACH__
	//	Precompile standard libraries
	#if !defined(__XCODE_GLIBC__) || (!__XCODE_GLIBC__)
		#include <MSLCarbonPrefix.h>
		#define MACHO			1
		#undef __NOEXTENSIONS__
		#include <Carbon/Carbon.h>
		#include <CoreServices/CoreServices.h>
	#else
		#define MACHO			1
		#undef __NOEXTENSIONS__
		#include <Carbon/Carbon.h>
		#include <CoreServices/CoreServices.h>
		#ifdef __cplusplus
		//	restrict is only a C-99 thing so we cannot use it in C++
			#define _MSL_RESTRICT const
			#ifdef _DEBUG
				#include "pp.xcode.deb.pch"
			#else
				#include "pp.xcode.pch"
			#endif
			#include	<algorithm>
			#include	<typeinfo>
			#include	<memory>
			#include	<limits>
			#include	<vector>
		#else
			#define _MSL_RESTRICT restrict
				//	Requires that GCC C99 or GNU99 flags are set
		#endif
		#define _MSL_CDECL
	#endif
#else
// include this next line ONLY if using MSL as a dll
// this includes any staticly linked library into DW/UD
#include "UseDLLPrefix.h"	
#endif

#define MFC2PP_FLASH
#define MFC2PP_MDI

#include "mfc2pp.carb.opt"
#include "mfc2x.opt"

#define JSFILE
#define MFC2X
