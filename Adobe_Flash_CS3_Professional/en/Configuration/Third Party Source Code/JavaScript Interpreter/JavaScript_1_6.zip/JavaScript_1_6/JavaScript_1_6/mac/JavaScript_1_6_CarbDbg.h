// This header is included with every file for the Mac build
//	_DEBUG is the only thing we define here, all others should be in the js32lib_mac.h
#define _DEBUG

#include "JavaScript_1_6_Carb.h"




